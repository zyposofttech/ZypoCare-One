export type Principal = {
  userId?: string;
  roleCode?: string;
  branchId?: string;
};
